#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CACHE="$ROOT/.native-cache"
TAG="${LIBXRAY_TAG:-v26.7.28}"
mkdir -p "$CACHE" "$ROOT/app/libs"
if [[ ! -d "$CACHE/libXray/.git" ]]; then
  git clone --depth 1 --branch "$TAG" https://github.com/XTLS/libXray.git "$CACHE/libXray"
else
  git -C "$CACHE/libXray" fetch --depth 1 origin "refs/tags/$TAG:refs/tags/$TAG"
  git -C "$CACHE/libXray" checkout -f "$TAG"
fi
cd "$CACHE/libXray"
python3 build/main.py android
[[ -f libXray.aar ]] || { echo "libXray.aar was not produced" >&2; exit 1; }
cp -f libXray.aar "$ROOT/app/libs/libXray.aar"
[[ -f libXray-sources.jar ]] && cp -f libXray-sources.jar "$ROOT/app/libs/libXray-sources.jar" || true
echo "Installed official XTLS/libXray $TAG -> app/libs/libXray.aar"
