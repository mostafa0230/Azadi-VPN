#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PACKAGE_ROOT="$(cd "$ROOT/.." && pwd)"
"$ROOT/scripts/build-libxray.sh"
cd "$ROOT"
./gradlew clean
./gradlew test
./gradlew assembleDebug
./gradlew bundleRelease
mkdir -p "$PACKAGE_ROOT/Release"
rm -f "$PACKAGE_ROOT/Release/BUILD_NOT_PRODUCED_IN_THIS_ENVIRONMENT.txt"
cp -f app/build/outputs/apk/debug/app-debug.apk "$PACKAGE_ROOT/Release/Azadi-debug.apk"
cp -f app/build/outputs/bundle/release/app-release.aab "$PACKAGE_ROOT/Release/Azadi-release.aab"
if [[ -n "${AZADI_KEYSTORE_PATH:-}" ]]; then
  echo "Release signing variables detected; AAB should be upload-key signed."
else
  echo "WARNING: no release keystore variables detected. The AAB is not suitable for Play upload until signed."
fi
sha256sum "$PACKAGE_ROOT/Release/Azadi-debug.apk" "$PACKAGE_ROOT/Release/Azadi-release.aab" > "$PACKAGE_ROOT/Release/SHA256SUMS.txt"
