plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val testAdMobAppId = "ca-app-pub-3940256099942544~3347511713"
val testBannerId = "ca-app-pub-3940256099942544/9214589741"
val testInterstitialId = "ca-app-pub-3940256099942544/1033173712"

fun prop(name: String, fallback: String) = providers.gradleProperty(name).orElse(fallback).get()

android {
    namespace = "com.azadi.freedom.vpnclient"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.azadi.freedom.vpnclient"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true
    }

    val releaseKeystorePath = providers.environmentVariable("AZADI_KEYSTORE_PATH").orNull
    val releaseKeystorePassword = providers.environmentVariable("AZADI_KEYSTORE_PASSWORD").orNull
    val releaseKeyAlias = providers.environmentVariable("AZADI_KEY_ALIAS").orNull
    val releaseKeyPassword = providers.environmentVariable("AZADI_KEY_PASSWORD").orNull
    val hasReleaseSigning = listOf(releaseKeystorePath, releaseKeystorePassword, releaseKeyAlias, releaseKeyPassword).all { !it.isNullOrBlank() }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseKeystorePath!!)
                storePassword = releaseKeystorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            manifestPlaceholders["admobAppId"] = testAdMobAppId
            buildConfigField("String", "ADMOB_BANNER_ID", "\"$testBannerId\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"$testInterstitialId\"")
            buildConfigField("boolean", "ADS_USE_TEST_IDS", "true")
        }
        release {
            if (hasReleaseSigning) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Builds remain possible without production AdMob credentials, but publishing must replace test IDs.
            manifestPlaceholders["admobAppId"] = prop("AZADI_ADMOB_APP_ID", testAdMobAppId)
            buildConfigField("String", "ADMOB_BANNER_ID", "\"${prop("AZADI_ADMOB_BANNER_ID", testBannerId)}\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"${prop("AZADI_ADMOB_INTERSTITIAL_ID", testInterstitialId)}\"")
            buildConfigField("boolean", "ADS_USE_TEST_IDS", prop("AZADI_ADMOB_APP_ID", testAdMobAppId).equals(testAdMobAppId).toString())
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
    packaging {
        jniLibs.useLegacyPackaging = false
        resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.9.1")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    // Official XTLS/libXray Android artifact is created by scripts/build-libxray.sh or CI.
    implementation(files("libs/libXray.aar"))

    // Ads + consent. Debug uses Google's test identifiers only.
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.android.ump:user-messaging-platform:4.0.0")

    // QR scanning (open-source ZXing embedding).
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")
}
