package com.azadi.freedom.vpnclient.testing

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScoreEngineTest {
    @Test fun timeout_isZero() {
        assertEquals(0, ScoreEngine.calculate(null, null, 0.0).score)
    }

    @Test fun fasterStableServer_scoresHigher() {
        val fast = ScoreEngine.calculate(42, 5, 1.0).score
        val slow = ScoreEngine.calculate(180, 30, 2.0 / 3.0).score
        assertTrue(fast > slow)
    }
}
