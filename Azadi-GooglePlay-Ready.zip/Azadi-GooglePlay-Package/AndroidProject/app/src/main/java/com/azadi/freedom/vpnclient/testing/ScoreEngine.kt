package com.azadi.freedom.vpnclient.testing

import kotlin.math.min

data class QualityScore(val score: Int, val label: String)

object ScoreEngine {
    fun calculate(latencyMs: Long?, jitterMs: Long?, successRatio: Double?): QualityScore {
        if (latencyMs == null || successRatio == null || successRatio <= 0.0) return QualityScore(0, "Timeout")
        val latencyPenalty = min(65.0, latencyMs / 5.0)
        val jitterPenalty = min(15.0, (jitterMs ?: 0L) / 4.0)
        val reliabilityPenalty = (1.0 - successRatio.coerceIn(0.0, 1.0)) * 50.0
        val score = (100.0 - latencyPenalty - jitterPenalty - reliabilityPenalty).toInt().coerceIn(0, 100)
        val label = when {
            score >= 85 -> "Excellent"
            score >= 70 -> "Very Good"
            score >= 55 -> "Good"
            score >= 35 -> "Weak"
            else -> "Poor"
        }
        return QualityScore(score, label)
    }
}
