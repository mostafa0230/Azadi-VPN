package com.azadi.freedom.vpnclient

import android.app.Application
import com.azadi.freedom.vpnclient.ads.ConsentManager
import com.azadi.freedom.vpnclient.data.ProfileStore
import com.azadi.freedom.vpnclient.vpn.VpnStateRepository

class AzadiApplication : Application() {
    lateinit var profileStore: ProfileStore
        private set
    lateinit var vpnStateRepository: VpnStateRepository
        private set
    lateinit var consentManager: ConsentManager
        private set

    override fun onCreate() {
        super.onCreate()
        profileStore = ProfileStore(this)
        vpnStateRepository = VpnStateRepository(this)
        consentManager = ConsentManager(this)
    }
}
