package com.azadi.freedom.vpnclient.vpn

enum class VpnState { OFF, CONNECTING, ON, ERROR }

data class VpnSnapshot(
    val state: VpnState = VpnState.OFF,
    val profileId: String? = null,
    val profileName: String? = null,
    val error: String? = null,
    val downBytesPerSecond: Long = 0,
    val upBytesPerSecond: Long = 0,
)
