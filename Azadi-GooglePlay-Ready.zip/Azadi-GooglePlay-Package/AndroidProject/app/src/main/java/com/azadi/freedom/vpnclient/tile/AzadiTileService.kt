package com.azadi.freedom.vpnclient.tile

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.net.VpnService
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.azadi.freedom.vpnclient.AzadiApplication
import com.azadi.freedom.vpnclient.ui.MainActivity
import com.azadi.freedom.vpnclient.vpn.AzadiVpnService
import com.azadi.freedom.vpnclient.vpn.VpnState

class AzadiTileService : TileService() {
    private val app get() = application as AzadiApplication

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        when (app.vpnStateRepository.current().state) {
            VpnState.ON, VpnState.CONNECTING -> AzadiVpnService.disconnect(this)
            VpnState.OFF, VpnState.ERROR -> {
                if (app.profileStore.selected() == null) {
                    openApp("no_profile")
                } else if (VpnService.prepare(this) != null) {
                    // Android requires the one-time VPN consent UI to be granted from an Activity.
                    openApp("request_vpn_permission")
                } else {
                    AzadiVpnService.connect(this, app.profileStore.selected()?.id)
                }
            }
        }
        refresh()
    }

    @Suppress("DEPRECATION")
    private fun openApp(reason: String) {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(MainActivity.EXTRA_TILE_REASON, reason)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val pending = PendingIntent.getActivity(
                this, reason.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            startActivityAndCollapse(pending)
        } else {
            startActivityAndCollapse(intent)
        }
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val snapshot = app.vpnStateRepository.current()
        tile.state = when (snapshot.state) {
            VpnState.ON -> Tile.STATE_ACTIVE
            VpnState.CONNECTING -> Tile.STATE_UNAVAILABLE
            VpnState.OFF, VpnState.ERROR -> Tile.STATE_INACTIVE
        }
        tile.label = "آزادی VPN"
        if (Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = when (snapshot.state) {
                VpnState.ON -> snapshot.profileName ?: "متصل"
                VpnState.CONNECTING -> "در حال اتصال"
                VpnState.ERROR -> "خطا"
                VpnState.OFF -> "خاموش"
            }
        }
        tile.updateTile()
    }
}
