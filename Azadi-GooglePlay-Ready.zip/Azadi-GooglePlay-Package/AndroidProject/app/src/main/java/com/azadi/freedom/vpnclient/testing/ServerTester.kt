package com.azadi.freedom.vpnclient.testing

import com.azadi.freedom.vpnclient.core.XrayConfigBuilder
import com.azadi.freedom.vpnclient.core.XrayNative
import com.azadi.freedom.vpnclient.data.Profile
import com.azadi.freedom.vpnclient.data.ProfileStore
import com.azadi.freedom.vpnclient.vpn.VpnState
import com.azadi.freedom.vpnclient.vpn.VpnStateRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToLong

class ServerTester(
    private val store: ProfileStore,
    private val stateRepository: VpnStateRepository,
) {
    data class TestResult(
        val profile: Profile,
        val success: Boolean,
        val latencyMs: Long?,
        val jitterMs: Long?,
        val successRatio: Double,
        val score: QualityScore,
        val error: String?,
    )

    suspend fun testAll(profiles: List<Profile> = store.getAll()): List<TestResult> = withContext(Dispatchers.IO) {
        require(stateRepository.current().state != VpnState.ON && stateRepository.current().state != VpnState.CONNECTING) {
            "برای جلوگیری از تداخل وضعیت داخلی Xray، قبل از تست سرورها VPN را قطع کنید"
        }
        val output = mutableListOf<TestResult>()
        // Three real rounds allow a stability/jitter estimate. Nothing is randomized.
        profiles.chunked(5).forEach { chunk ->
            val configs = chunk.map { XrayConfigBuilder.outboundOnly(it.rawLink) }
            val rounds = MutableList(chunk.size) { mutableListOf<Long>() }
            val errors = MutableList<String?>(chunk.size) { null }
            repeat(3) {
                val native = XrayNative.pingBatch(configs, timeoutSeconds = 5)
                native.forEachIndexed { index, result ->
                    if (result.success && result.delayMs in 1..9_999) rounds[index] += result.delayMs
                    else errors[index] = result.error ?: if (result.delayMs == 11_000L) "Timeout" else "Connection failed"
                }
            }
            chunk.forEachIndexed { index, profile ->
                val values = rounds[index]
                val ratio = values.size / 3.0
                val latency = values.takeIf { it.isNotEmpty() }?.average()?.roundToLong()
                val jitter = if (values.size >= 2) {
                    values.zipWithNext { a, b -> kotlin.math.abs(a - b).toDouble() }.average().roundToLong()
                } else null
                val score = ScoreEngine.calculate(latency, jitter, ratio)
                val error = if (ratio == 0.0) errors[index] else null
                store.updateTest(profile.id, latency, jitter, ratio, error)
                output += TestResult(profile, ratio > 0.0, latency, jitter, ratio, score, error)
            }
        }
        output.sortedWith(compareByDescending<TestResult> { it.score.score }.thenBy { it.latencyMs ?: Long.MAX_VALUE })
    }

    suspend fun bestProfile(): Profile? {
        val results = testAll()
        return results.firstOrNull { it.success }?.let { best -> store.getAll().firstOrNull { it.id == best.profile.id } }
    }
}
