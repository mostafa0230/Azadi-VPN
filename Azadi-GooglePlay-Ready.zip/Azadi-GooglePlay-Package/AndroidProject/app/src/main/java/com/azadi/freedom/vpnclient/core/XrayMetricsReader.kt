package com.azadi.freedom.vpnclient.core

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.Socket

data class TunnelBytes(val downlink: Long, val uplink: Long)

object XrayMetricsReader {
    fun read(timeoutMs: Int = 750): TunnelBytes? = runCatching {
        Socket().use { socket ->
            socket.connect(InetSocketAddress("127.0.0.1", XrayConfigBuilder.METRICS_PORT), timeoutMs)
            socket.soTimeout = timeoutMs
            OutputStreamWriter(socket.getOutputStream(), Charsets.US_ASCII).use { writer ->
                writer.write("GET /debug/vars HTTP/1.0\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n")
                writer.flush()
            }
            val body = BufferedReader(InputStreamReader(socket.getInputStream())).readText().substringAfter("\r\n\r\n")
            val root = JSONObject(body)
            val tun = root.optJSONObject("stats")?.optJSONObject("inbound")?.optJSONObject("azadi-tun")
                ?: return@runCatching null
            TunnelBytes(
                downlink = tun.optLong("downlink", 0L),
                uplink = tun.optLong("uplink", 0L),
            )
        }
    }.getOrNull()
}
