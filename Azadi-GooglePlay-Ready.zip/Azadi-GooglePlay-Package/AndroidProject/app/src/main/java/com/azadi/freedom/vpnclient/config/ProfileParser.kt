package com.azadi.freedom.vpnclient.config

import android.net.Uri
import android.util.Base64
import com.azadi.freedom.vpnclient.data.Profile
import com.azadi.freedom.vpnclient.data.ProxyProtocol
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID

sealed class ParseResult {
    data class Success(val profile: Profile) : ParseResult()
    data class Failure(val input: String, val reason: String) : ParseResult()
}

object ProfileParser {
    fun parse(input: String): ParseResult {
        val value = input.trim()
        if (value.isBlank()) return ParseResult.Failure(input, "کانفیگ خالی است")
        return try {
            when {
                value.startsWith("vless://", ignoreCase = true) -> parseVless(value)
                value.startsWith("vmess://", ignoreCase = true) -> parseVmess(value)
                value.startsWith("{") -> parseJson(value)
                else -> ParseResult.Failure(value, "فقط VLESS، VMess یا JSON پشتیبانی می‌شود")
            }
        } catch (t: Throwable) {
            ParseResult.Failure(value, t.message ?: "ساختار کانفیگ معتبر نیست")
        }
    }

    private fun parseVless(link: String): ParseResult {
        val uri = Uri.parse(link)
        val uuidText = uri.userInfo?.substringBefore(':')?.trim().orEmpty()
        if (!isUuid(uuidText)) return ParseResult.Failure(link, "UUID در VLESS معتبر نیست")
        val address = uri.host?.trim().orEmpty()
        if (address.isBlank()) return ParseResult.Failure(link, "آدرس سرور VLESS وجود ندارد")
        val port = uri.port
        if (port !in 1..65535) return ParseResult.Failure(link, "پورت VLESS معتبر نیست")

        val type = uri.getQueryParameter("type")?.ifBlank { "tcp" } ?: "tcp"
        val security = uri.getQueryParameter("security")?.ifBlank { "none" } ?: "none"
        if (security.equals("none", true)) {
            return ParseResult.Failure(link, "برای نسخه Google Play، VLESS بدون TLS/Reality پذیرفته نمی‌شود؛ ترافیک VPN باید تا endpoint رمزگذاری شود")
        }
        val name = Uri.decode(uri.fragment ?: "VLESS ${maskHost(address)}")
        return ParseResult.Success(
            Profile(
                id = stableId(link),
                name = name.ifBlank { "VLESS ${maskHost(address)}" },
                protocol = ProxyProtocol.VLESS,
                rawLink = link,
                address = address,
                port = port,
                transport = type,
                security = security,
            )
        )
    }

    private fun parseVmess(link: String): ParseResult {
        val encoded = link.removePrefix("vmess://").trim()
        if (encoded.isBlank()) return ParseResult.Failure(link, "داده VMess خالی است")
        val decoded = decodeBase64(encoded)
            ?: return ParseResult.Failure(link, "Base64 مربوط به VMess معتبر نیست")
        return parseVmessJson(decoded, link)
    }

    private fun parseJson(json: String): ParseResult {
        val o = JSONObject(json)
        // Common VMess share JSON can be imported directly.
        if (o.has("add") && o.has("id")) return parseVmessJson(json, "vmess://${encodeBase64(json)}")
        return ParseResult.Failure(json, "JSON خام Xray باید از بخش Import Core وارد شود؛ JSON فعلی Profile VMess نیست")
    }

    private fun parseVmessJson(json: String, rawLink: String): ParseResult {
        val o = JSONObject(json)
        val address = o.optString("add").trim()
        if (address.isBlank()) return ParseResult.Failure(rawLink, "آدرس سرور VMess وجود ندارد")
        val port = when (val p = o.opt("port")) {
            is Number -> p.toInt()
            else -> p?.toString()?.toIntOrNull() ?: -1
        }
        if (port !in 1..65535) return ParseResult.Failure(rawLink, "پورت VMess معتبر نیست")
        val id = o.optString("id").trim()
        if (!isUuid(id)) return ParseResult.Failure(rawLink, "UUID در VMess معتبر نیست")
        val name = o.optString("ps").ifBlank { "VMess ${maskHost(address)}" }
        val net = o.optString("net").ifBlank { "tcp" }
        val tls = o.optString("tls").ifBlank { "none" }
        val cipher = o.optString("scy").ifBlank { "auto" }
        if (cipher.equals("none", true) || cipher.equals("zero", true)) {
            return ParseResult.Failure(rawLink, "VMess با cipher=none برای نسخه Google Play پذیرفته نمی‌شود")
        }
        return ParseResult.Success(
            Profile(
                id = stableId(rawLink),
                name = name,
                protocol = ProxyProtocol.VMESS,
                rawLink = rawLink,
                address = address,
                port = port,
                transport = net,
                security = tls,
            )
        )
    }

    private fun decodeBase64(value: String): String? {
        val padded = value + "=".repeat((4 - value.length % 4) % 4)
        val flags = intArrayOf(Base64.URL_SAFE or Base64.NO_WRAP, Base64.DEFAULT)
        for (flag in flags) {
            try {
                return String(Base64.decode(padded, flag), StandardCharsets.UTF_8)
            } catch (_: IllegalArgumentException) { }
        }
        return null
    }

    private fun encodeBase64(value: String): String =
        Base64.encodeToString(value.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)

    private fun stableId(raw: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.trim().toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.take(24)
    }

    private fun isUuid(value: String): Boolean = try {
        UUID.fromString(value); true
    } catch (_: Throwable) { false }

    private fun maskHost(host: String): String = if (host.length <= 16) host else host.take(8) + "…"
}
