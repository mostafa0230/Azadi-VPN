package com.azadi.freedom.vpnclient.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.azadi.freedom.vpnclient.R
import com.azadi.freedom.vpnclient.ui.MainActivity
import com.azadi.freedom.vpnclient.vpn.VpnSnapshot
import com.azadi.freedom.vpnclient.vpn.VpnState
import java.util.Locale

class VpnNotificationManager(private val context: Context) {
    private val manager = context.getSystemService(NotificationManager::class.java)

    init {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.vpn_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "وضعیت اتصال VPN آزادی"
                setShowBadge(false)
            })
        }
    }

    fun build(snapshot: VpnSnapshot): android.app.Notification {
        val openIntent = PendingIntent.getActivity(
            context, 1, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val disconnectIntent = PendingIntent.getBroadcast(
            context, 2,
            Intent(context, DisconnectReceiver::class.java).setAction(DisconnectReceiver.ACTION_DISCONNECT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val title = when (snapshot.state) {
            VpnState.ON -> "آزادی VPN • متصل"
            VpnState.CONNECTING -> "آزادی VPN • در حال اتصال"
            VpnState.ERROR -> "آزادی VPN • خطا"
            VpnState.OFF -> "آزادی VPN"
        }
        val content = when (snapshot.state) {
            VpnState.ON -> "${snapshot.profileName ?: "سرور"}  ↓ ${rate(snapshot.downBytesPerSecond)}  ↑ ${rate(snapshot.upBytesPerSecond)}"
            VpnState.ERROR -> snapshot.error ?: "خطای اتصال"
            else -> snapshot.profileName ?: ""
        }
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_vpn_key)
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(openIntent)
            .setOngoing(snapshot.state == VpnState.ON || snapshot.state == VpnState.CONNECTING)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .addAction(0, "قطع اتصال", disconnectIntent)
            .build()
    }

    fun notify(snapshot: VpnSnapshot) = manager.notify(NOTIFICATION_ID, build(snapshot))
    fun cancel() = manager.cancel(NOTIFICATION_ID)

    private fun rate(bytes: Long): String {
        val value = bytes.coerceAtLeast(0)
        return when {
            value >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB/s", value / 1048576.0)
            value >= 1024L -> String.format(Locale.US, "%.0f KB/s", value / 1024.0)
            else -> "$value B/s"
        }
    }

    companion object {
        const val CHANNEL_ID = "azadi_vpn"
        const val NOTIFICATION_ID = 1101
    }
}
