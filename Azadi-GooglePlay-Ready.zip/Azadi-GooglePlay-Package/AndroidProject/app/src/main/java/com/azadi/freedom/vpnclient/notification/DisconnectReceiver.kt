package com.azadi.freedom.vpnclient.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.azadi.freedom.vpnclient.vpn.AzadiVpnService

class DisconnectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_DISCONNECT) AzadiVpnService.disconnect(context)
    }

    companion object { const val ACTION_DISCONNECT = "com.azadi.freedom.vpnclient.action.NOTIFICATION_DISCONNECT" }
}
