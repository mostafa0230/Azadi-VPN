package com.azadi.freedom.vpnclient.vpn

import android.content.ComponentName
import android.content.Context
import android.service.quicksettings.TileService
import com.azadi.freedom.vpnclient.tile.AzadiTileService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class VpnStateRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("azadi_vpn_state", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<VpnSnapshot> = _state.asStateFlow()

    fun current(): VpnSnapshot = _state.value

    @Synchronized
    fun update(snapshot: VpnSnapshot) {
        _state.value = snapshot
        prefs.edit()
            .putString("state", snapshot.state.name)
            .putString("profileId", snapshot.profileId)
            .putString("profileName", snapshot.profileName)
            .putString("error", snapshot.error)
            .apply()
        TileService.requestListeningState(context, ComponentName(context, AzadiTileService::class.java))
    }

    fun updateTraffic(down: Long, up: Long) {
        _state.value = _state.value.copy(downBytesPerSecond = down.coerceAtLeast(0), upBytesPerSecond = up.coerceAtLeast(0))
    }

    private fun load(): VpnSnapshot {
        val saved = runCatching { VpnState.valueOf(prefs.getString("state", VpnState.OFF.name)!!) }.getOrDefault(VpnState.OFF)
        // A process restart cannot prove that Xray is still alive. Service restores ON after native state check.
        val safeState = if (saved == VpnState.ON || saved == VpnState.CONNECTING) VpnState.OFF else saved
        return VpnSnapshot(
            state = safeState,
            profileId = prefs.getString("profileId", null),
            profileName = prefs.getString("profileName", null),
            error = prefs.getString("error", null),
        )
    }
}
