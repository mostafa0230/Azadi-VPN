package com.azadi.freedom.vpnclient.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.azadi.freedom.vpnclient.AzadiApplication
import com.azadi.freedom.vpnclient.R
import com.azadi.freedom.vpnclient.ads.AdManager
import com.azadi.freedom.vpnclient.config.ProfileImportService
import com.azadi.freedom.vpnclient.core.XrayNative
import com.azadi.freedom.vpnclient.data.Profile
import com.azadi.freedom.vpnclient.databinding.ActivityMainBinding
import com.azadi.freedom.vpnclient.testing.ServerTester
import com.azadi.freedom.vpnclient.vpn.AzadiVpnService
import com.azadi.freedom.vpnclient.vpn.VpnSnapshot
import com.azadi.freedom.vpnclient.vpn.VpnState
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var app: AzadiApplication
    private lateinit var adapter: ProfileAdapter
    private lateinit var importer: ProfileImportService
    private lateinit var tester: ServerTester
    private lateinit var ads: AdManager
    private var pendingConnectProfileId: String? = null
    private var bannerLoaded = false

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) AzadiVpnService.connect(this, pendingConnectProfileId ?: app.profileStore.selected()?.id)
        else toast("مجوز VPN داده نشد")
        pendingConnectProfileId = null
    }

    private val openConfigFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) lifecycleScope.launch { importFromUri(uri) }
    }

    private val createExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) exportTo(uri)
    }

    private val qrScanner = registerForActivityResult(ScanContract()) { result ->
        result.contents?.let { importText(it) }
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        app = application as AzadiApplication
        importer = ProfileImportService(app.profileStore)
        tester = ServerTester(app.profileStore, app.vpnStateRepository)
        ads = AdManager(this)
        setupList()
        setupActions()
        observeState()
        refreshProfiles()

        binding.coreVersion.text = runCatching { "Xray ${XrayNative.version() ?: "core"}" }.getOrDefault("Xray core")
        app.consentManager.request(this) { canRequest ->
            if (canRequest) runOnUiThread { startAds() }
        }

        intent.dataString?.takeIf { it.startsWith("vless://") || it.startsWith("vmess://") }?.let { importText(it) }
        when (intent.getStringExtra(EXTRA_TILE_REASON)) {
            "request_vpn_permission" -> prepareAndConnect(app.profileStore.selected()?.id)
            "no_profile" -> showImportMenu()
        }
    }

    private fun setupList() {
        adapter = ProfileAdapter(
            onSelect = { profile -> app.profileStore.setSelectedId(profile.id); refreshProfiles() },
            onLongPress = { profile -> confirmDelete(profile) },
        )
        binding.serverList.layoutManager = LinearLayoutManager(this)
        binding.serverList.adapter = adapter
    }

    private fun setupActions() {
        binding.connectButton.setOnClickListener {
            when (app.vpnStateRepository.current().state) {
                VpnState.ON, VpnState.CONNECTING -> AzadiVpnService.disconnect(this)
                VpnState.OFF, VpnState.ERROR -> {
                    val selected = app.profileStore.selected()
                    if (selected == null) showImportMenu() else ensureDisclosureThenConnect(selected.id)
                }
            }
        }
        binding.importButton.setOnClickListener { showImportMenu() }
        binding.testAllButton.setOnClickListener { runTests(connectBest = false) }
        binding.bestServerButton.setOnClickListener { runTests(connectBest = true) }
        binding.exportButton.setOnClickListener {
            if (app.profileStore.getAll().isEmpty()) toast("کانفیگی برای Export وجود ندارد")
            else createExport.launch("azadi-profiles.txt")
        }
        binding.privacyButton.setOnClickListener {
            if (app.consentManager.privacyOptionsRequired()) app.consentManager.showPrivacyOptions(this) { it?.let(::toast) }
            else toast("در حال حاضر Privacy Options اضافی برای این منطقه لازم نیست")
        }
        binding.killSwitchButton.setOnClickListener { showKillSwitchInfo() }
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                app.vpnStateRepository.state.collect { snapshot ->
                    renderState(snapshot)
                }
            }
        }
    }

    private fun renderState(snapshot: VpnSnapshot) {
        val selected = app.profileStore.selected()
        binding.selectedServer.text = "سرور: ${snapshot.profileName ?: selected?.name ?: "انتخاب نشده"}"
        binding.statusDot.text = when (snapshot.state) {
            VpnState.OFF -> "● OFF"
            VpnState.CONNECTING -> "● CONNECTING"
            VpnState.ON -> "● CONNECTED"
            VpnState.ERROR -> "● ERROR"
        }
        binding.statusDot.setTextColor(ContextCompat.getColor(this, when (snapshot.state) {
            VpnState.ON -> R.color.azadi_green
            VpnState.CONNECTING -> R.color.azadi_gold
            VpnState.OFF, VpnState.ERROR -> R.color.azadi_red
        }))
        binding.statusText.text = when (snapshot.state) {
            VpnState.OFF -> "متصل نیست"
            VpnState.CONNECTING -> "در حال برقراری تونل واقعی…"
            VpnState.ON -> "متصل"
            VpnState.ERROR -> snapshot.error ?: "خطای اتصال"
        }
        binding.connectButton.text = if (snapshot.state == VpnState.ON || snapshot.state == VpnState.CONNECTING) "قطع اتصال" else "اتصال"
        binding.liveTraffic.text = "↓ ${rate(snapshot.downBytesPerSecond)}   ↑ ${rate(snapshot.upBytesPerSecond)}"
        val canTest = snapshot.state == VpnState.OFF || snapshot.state == VpnState.ERROR
        binding.testAllButton.isEnabled = canTest
        binding.bestServerButton.isEnabled = canTest
    }

    private fun ensureDisclosureThenConnect(profileId: String) {
        val prefs = getSharedPreferences("azadi_disclosure", MODE_PRIVATE)
        if (prefs.getBoolean("vpn_accepted_v1", false)) {
            prepareAndConnect(profileId); return
        }
        AlertDialog.Builder(this)
            .setTitle("VPN چگونه کار می‌کند؟")
            .setMessage(
                "آزادی با Android VpnService یک رابط VPN روی دستگاه ایجاد می‌کند و ترافیک شبکه را از طریق Xray-core و سروری که خودتان وارد و انتخاب کرده‌اید عبور می‌دهد. " +
                    "کانفیگ شامل آدرس و اطلاعات احراز هویت سرور است و به‌صورت رمزگذاری‌شده در فضای خصوصی برنامه نگهداری می‌شود. " +
                    "آزادی محتوای مقصدهای شما را برای ساخت پروفایل تبلیغاتی ثبت نمی‌کند؛ با این حال سرویس تبلیغاتی Google داده‌های لازم برای تبلیغات/تشخیص تقلب را طبق رضایت شما پردازش می‌کند."
            )
            .setNegativeButton("لغو", null)
            .setPositiveButton("می‌پذیرم و ادامه") { _, _ ->
                prefs.edit().putBoolean("vpn_accepted_v1", true).apply()
                prepareAndConnect(profileId)
            }.show()
    }

    private fun prepareAndConnect(profileId: String?) {
        if (profileId == null) { showImportMenu(); return }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        pendingConnectProfileId = profileId
        val intent = VpnService.prepare(this)
        if (intent == null) {
            AzadiVpnService.connect(this, profileId)
            pendingConnectProfileId = null
        } else vpnPermission.launch(intent)
    }

    private fun showImportMenu() {
        val options = arrayOf("Paste / متن کانفیگ", "Import فایل / JSON", "Scan QR Code")
        AlertDialog.Builder(this).setTitle("افزودن کانفیگ").setItems(options) { _, which ->
            when (which) {
                0 -> showPasteDialog()
                1 -> openConfigFile.launch(arrayOf("text/plain", "application/json", "application/octet-stream", "*/*"))
                2 -> qrScanner.launch(ScanOptions().setPrompt("QR کانفیگ VLESS یا VMess را اسکن کنید").setBeepEnabled(false).setOrientationLocked(false))
            }
        }.show()
    }

    private fun showPasteDialog() {
        val edit = EditText(this).apply {
            minLines = 7; maxLines = 14
            hint = "vless://…\nvmess://…\nیا JSON"
            setPadding(36, 24, 36, 24)
        }
        AlertDialog.Builder(this)
            .setTitle("Import Configuration")
            .setView(edit)
            .setNegativeButton("لغو", null)
            .setPositiveButton("Import") { _, _ -> importText(edit.text.toString()) }
            .show()
    }

    private fun importText(text: String) {
        if (text.isBlank()) return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { importer.importText(text) }
            refreshProfiles()
            val summary = buildString {
                append("${result.imported.size} کانفیگ اضافه شد")
                if (result.duplicates.isNotEmpty()) append(" • ${result.duplicates.size} تکراری")
                if (result.rejected.isNotEmpty()) append(" • ${result.rejected.size} رد شد")
            }
            toast(summary)
            if (result.rejected.isNotEmpty()) AlertDialog.Builder(this@MainActivity)
                .setTitle("کانفیگ‌های ردشده")
                .setMessage(result.rejected.joinToString("\n\n").take(5000))
                .setPositiveButton("باشه", null).show()
            if (result.imported.isNotEmpty()) ads.showNaturalInterstitial(this@MainActivity)
        }
    }

    private suspend fun importFromUri(uri: Uri) {
        val text = withContext(Dispatchers.IO) {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
        }
        importText(text)
    }

    private fun exportTo(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            val text = app.profileStore.getAll().joinToString("\n") { it.rawLink }
            runCatching { contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) } }
                .onSuccess { withContext(Dispatchers.Main) { toast("Export انجام شد") } }
                .onFailure { withContext(Dispatchers.Main) { toast("Export ناموفق بود: ${it.message}") } }
        }
    }

    private fun runTests(connectBest: Boolean) {
        if (app.profileStore.getAll().isEmpty()) { showImportMenu(); return }
        binding.testAllButton.isEnabled = false
        binding.bestServerButton.isEnabled = false
        lifecycleScope.launch {
            try {
                val results = tester.testAll()
                refreshProfiles()
                val best = results.firstOrNull { it.success }
                if (best == null) toast("هیچ سروری پاسخ نداد")
                else {
                    toast("بهترین: ${best.profile.name} • ${best.latencyMs} ms • ${best.score.label}")
                    if (connectBest) {
                        app.profileStore.setSelectedId(best.profile.id)
                        refreshProfiles()
                        ensureDisclosureThenConnect(best.profile.id)
                    } else ads.showNaturalInterstitial(this@MainActivity)
                }
            } catch (t: Throwable) {
                toast(t.message ?: "تست سرورها ناموفق بود")
            } finally {
                renderState(app.vpnStateRepository.current())
            }
        }
    }

    private fun refreshProfiles() {
        val profiles = app.profileStore.getAll()
        adapter.submit(profiles, app.profileStore.getSelectedId())
        binding.serverCount.text = profiles.size.toString()
        binding.selectedServer.text = "سرور: ${app.profileStore.selected()?.name ?: "انتخاب نشده"}"
    }

    private fun confirmDelete(profile: Profile) {
        AlertDialog.Builder(this).setTitle("حذف ${profile.name}؟")
            .setMessage("این کانفیگ از حافظه رمزگذاری‌شده برنامه حذف می‌شود.")
            .setNegativeButton("لغو", null)
            .setPositiveButton("حذف") { _, _ -> app.profileStore.remove(profile.id); refreshProfiles() }
            .show()
    }

    private fun showKillSwitchInfo() {
        AlertDialog.Builder(this)
            .setTitle("مسدود کردن اتصال بدون VPN")
            .setMessage("Android اجازه نمی‌دهد یک برنامه معمولی خودش گزینه «Block connections without VPN» را مخفیانه فعال کند. در صفحه VPN سیستم، آزادی را به‌عنوان Always-on VPN انتخاب کنید و گزینه مسدود کردن اتصال بدون VPN را روشن کنید. این روش Kill Switch واقعی سیستم‌عامل است.")
            .setNegativeButton("بعداً", null)
            .setPositiveButton("باز کردن تنظیمات VPN") { _, _ -> startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }
            .show()
    }

    private fun startAds() {
        if (bannerLoaded) return
        bannerLoaded = true
        ads.initialize()
        binding.adContainer.removeAllViews()
        binding.adContainer.addView(ads.createBanner())
        ads.preloadInterstitial()
    }

    private fun rate(bytes: Long): String = when {
        bytes >= 1_048_576 -> String.format(Locale.US, "%.1f MB/s", bytes / 1_048_576.0)
        bytes >= 1024 -> String.format(Locale.US, "%.0f KB/s", bytes / 1024.0)
        else -> "$bytes B/s"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object { const val EXTRA_TILE_REASON = "tile_reason" }
}
