package com.azadi.freedom.vpnclient.config

import com.azadi.freedom.vpnclient.data.Profile

data class ImportReport(
    val imported: List<Profile>,
    val duplicates: List<String>,
    val rejected: List<ParseResult.Failure>,
)

object ImportEngine {
    fun parseMany(text: String, existingIds: Set<String> = emptySet()): ImportReport {
        val candidates = text
            .replace("\r", "\n")
            .split(Regex("[\\n\\t ]+(?=(?:vless|vmess)://)|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val imported = mutableListOf<Profile>()
        val duplicates = mutableListOf<String>()
        val rejected = mutableListOf<ParseResult.Failure>()
        val seen = existingIds.toMutableSet()

        candidates.forEach { candidate ->
            when (val result = ProfileParser.parse(candidate)) {
                is ParseResult.Success -> {
                    if (!seen.add(result.profile.id)) duplicates += result.profile.name
                    else imported += result.profile
                }
                is ParseResult.Failure -> rejected += result
            }
        }
        return ImportReport(imported, duplicates, rejected)
    }
}
