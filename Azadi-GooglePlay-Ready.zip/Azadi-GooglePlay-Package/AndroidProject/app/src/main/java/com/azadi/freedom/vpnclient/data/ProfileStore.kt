package com.azadi.freedom.vpnclient.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("azadi_profiles", Context.MODE_PRIVATE)
    private val alias = "azadi_profile_key_v1"

    @Synchronized
    fun getAll(): List<Profile> {
        val encrypted = prefs.getString(KEY_DATA, null) ?: return emptyList()
        return runCatching { decodeProfiles(decrypt(encrypted)) }.getOrDefault(emptyList())
    }

    @Synchronized
    fun saveAll(profiles: List<Profile>) {
        prefs.edit().putString(KEY_DATA, encrypt(encodeProfiles(profiles))).apply()
    }

    @Synchronized
    fun add(profiles: List<Profile>) {
        val merged = (getAll() + profiles).distinctBy { it.id }
        saveAll(merged)
    }

    @Synchronized
    fun remove(id: String) = saveAll(getAll().filterNot { it.id == id })

    @Synchronized
    fun updateTest(id: String, latency: Long?, jitter: Long?, successRatio: Double?, error: String?) {
        saveAll(getAll().map {
            if (it.id != id) it else it.copy(
                lastLatencyMs = latency,
                lastJitterMs = jitter,
                lastSuccessRatio = successRatio,
                lastTestAt = System.currentTimeMillis(),
                lastError = error,
            )
        })
    }

    fun getSelectedId(): String? = prefs.getString(KEY_SELECTED, null)
    fun setSelectedId(id: String?) = prefs.edit().putString(KEY_SELECTED, id).apply()
    fun selected(): Profile? = getAll().firstOrNull { it.id == getSelectedId() } ?: getAll().firstOrNull()

    private fun encodeProfiles(profiles: List<Profile>): String {
        val array = JSONArray()
        profiles.forEach { p ->
            array.put(JSONObject().apply {
                put("id", p.id); put("name", p.name); put("protocol", p.protocol.name)
                put("rawLink", p.rawLink); put("address", p.address); put("port", p.port)
                put("transport", p.transport); put("security", p.security); put("createdAt", p.createdAt)
                p.lastLatencyMs?.let { put("lastLatencyMs", it) }
                p.lastJitterMs?.let { put("lastJitterMs", it) }
                p.lastSuccessRatio?.let { put("lastSuccessRatio", it) }
                p.lastTestAt?.let { put("lastTestAt", it) }
                p.lastError?.let { put("lastError", it) }
            })
        }
        return array.toString()
    }

    private fun decodeProfiles(json: String): List<Profile> {
        val array = JSONArray(json)
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(Profile(
                    id = o.getString("id"), name = o.getString("name"),
                    protocol = ProxyProtocol.valueOf(o.getString("protocol")), rawLink = o.getString("rawLink"),
                    address = o.getString("address"), port = o.getInt("port"), transport = o.getString("transport"),
                    security = o.getString("security"), createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    lastLatencyMs = if (o.has("lastLatencyMs")) o.getLong("lastLatencyMs") else null,
                    lastJitterMs = if (o.has("lastJitterMs")) o.getLong("lastJitterMs") else null,
                    lastSuccessRatio = if (o.has("lastSuccessRatio")) o.getDouble("lastSuccessRatio") else null,
                    lastTestAt = if (o.has("lastTestAt")) o.getLong("lastTestAt") else null,
                    lastError = o.optString("lastError").takeIf { it.isNotBlank() },
                ))
            }
        }
    }

    private fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val data = cipher.doFinal(plain.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(cipher.iv + data, Base64.NO_WRAP)
    }

    private fun decrypt(encoded: String): String {
        val all = Base64.decode(encoded, Base64.NO_WRAP)
        require(all.size > 12) { "Encrypted profile store is invalid" }
        val iv = all.copyOfRange(0, 12)
        val ciphertext = all.copyOfRange(12, all.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8)
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    companion object {
        private const val KEY_DATA = "profiles_enc"
        private const val KEY_SELECTED = "selected_profile"
    }
}
