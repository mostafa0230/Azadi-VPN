package com.azadi.freedom.vpnclient.vpn

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.Build
import androidx.core.content.ContextCompat
import com.azadi.freedom.vpnclient.AzadiApplication
import com.azadi.freedom.vpnclient.core.VpnSocketProtector
import com.azadi.freedom.vpnclient.core.XrayConfigBuilder
import com.azadi.freedom.vpnclient.core.XrayMetricsReader
import com.azadi.freedom.vpnclient.core.XrayNative
import com.azadi.freedom.vpnclient.data.Profile
import com.azadi.freedom.vpnclient.notification.VpnNotificationManager
import com.azadi.freedom.vpnclient.testing.ScoreEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class AzadiVpnService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var app: AzadiApplication
    private lateinit var notifications: VpnNotificationManager
    private var tun: ParcelFileDescriptor? = null
    private var metricsJob: Job? = null
    private var reconnectJob: Job? = null
    private val userStopped = AtomicBoolean(false)
    private var lastConnectedProfileId: String? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        app = application as AzadiApplication
        notifications = VpnNotificationManager(this)
        registerNetworkCallback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action ?: ACTION_CONNECT) {
            ACTION_DISCONNECT -> disconnectInternal(true)
            ACTION_RECONNECT -> reconnectFinite()
            ACTION_CONNECT -> {
                userStopped.set(false)
                val profileId = intent?.getStringExtra(EXTRA_PROFILE_ID)
                scope.launch { connect(profileId) }
            }
        }
        return START_STICKY
    }

    private suspend fun connect(requestedProfileId: String?) {
        if (app.vpnStateRepository.current().state == VpnState.CONNECTING) return
        val all = app.profileStore.getAll()
        val selected = all.firstOrNull { it.id == requestedProfileId }
            ?: app.profileStore.selected()
            ?: run {
                setError("هیچ سروری انتخاب نشده است")
                stopSelf(); return
            }
        app.profileStore.setSelectedId(selected.id)
        closeTunnelAndCore()
        val connecting = VpnSnapshot(VpnState.CONNECTING, selected.id, selected.name)
        app.vpnStateRepository.update(connecting)
        startForeground(VpnNotificationManager.NOTIFICATION_ID, notifications.build(connecting))

        var lastError: Throwable? = null
        val candidates = orderedCandidates(selected, all)
        for (profile in candidates.take(MAX_PROFILE_CANDIDATES)) {
            if (userStopped.get()) return
            repeat(ATTEMPTS_PER_PROFILE) { attempt ->
                try {
                    establishAndRun(profile)
                    return
                } catch (t: Throwable) {
                    lastError = t
                    closeTunnelAndCore()
                    if (attempt < ATTEMPTS_PER_PROFILE - 1) delay(750L * (attempt + 1))
                }
            }
        }
        setError(lastError?.message ?: "اتصال برقرار نشد")
        stopForegroundCompat(remove = false)
        stopSelf()
    }

    private fun orderedCandidates(selected: Profile, all: List<Profile>): List<Profile> {
        val rest = all.filterNot { it.id == selected.id }.sortedByDescending {
            ScoreEngine.calculate(it.lastLatencyMs, it.lastJitterMs, it.lastSuccessRatio).score
        }
        return listOf(selected) + rest
    }

    private fun establishAndRun(profile: Profile) {
        // Prefer dual stack, but retry with IPv4-only on devices/networks that reject IPv6 VPN setup.
        tun = establishTun(profile.name, includeIpv6 = true)
            ?: establishTun(profile.name, includeIpv6 = false)
            ?: throw IllegalStateException("Android نتوانست رابط VPN را ایجاد کند")

        val protector = VpnSocketProtector(this)
        XrayNative.registerProtector(protector)
        XrayNative.setDns(protector, "1.1.1.1:53")
        val config = XrayConfigBuilder.fromShareLink(profile.rawLink, tun!!.fd)
        // Do not call testXray here: it creates a temporary Xray instance and can disturb
        // process-wide state, and a TUN config references this live fd. Import is already
        // validated by convertShareLinksToXrayJson; runXray is the authoritative runtime check.
        XrayNative.run(config)
        if (!XrayNative.isRunning()) throw IllegalStateException("Xray پس از اجرا Running نشد")

        lastConnectedProfileId = profile.id
        app.profileStore.setSelectedId(profile.id)
        val on = VpnSnapshot(VpnState.ON, profile.id, profile.name)
        app.vpnStateRepository.update(on)
        notifications.notify(on)
        startMetrics()
    }

    private fun establishTun(profileName: String, includeIpv6: Boolean): ParcelFileDescriptor? {
        val builder = Builder()
            .setSession("Azadi • $profileName")
            .setMtu(1500)
            .addAddress("10.18.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
        if (includeIpv6) {
            builder
                .addAddress("fd42:42:42::2", 128)
                .addRoute("::", 0)
                .addDnsServer("2606:4700:4700::1111")
        }
        return runCatching { builder.establish() }.getOrNull()
    }

    private fun startMetrics() {
        metricsJob?.cancel()
        metricsJob = scope.launch {
            var previous = XrayMetricsReader.read()
            var previousAt = System.nanoTime()
            while (isActive && app.vpnStateRepository.current().state == VpnState.ON) {
                delay(1_000)
                val now = XrayMetricsReader.read()
                val nowAt = System.nanoTime()
                if (previous != null && now != null) {
                    val seconds = (nowAt - previousAt) / 1_000_000_000.0
                    if (seconds > 0) {
                        val down = ((now.downlink - previous!!.downlink).coerceAtLeast(0) / seconds).toLong()
                        val up = ((now.uplink - previous!!.uplink).coerceAtLeast(0) / seconds).toLong()
                        app.vpnStateRepository.updateTraffic(down, up)
                        notifications.notify(app.vpnStateRepository.current())
                    }
                }
                previous = now
                previousAt = nowAt
            }
        }
    }

    private fun reconnectFinite() {
        if (userStopped.get()) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            closeTunnelAndCore()
            delay(500)
            connect(lastConnectedProfileId ?: app.profileStore.getSelectedId())
        }
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                if (app.vpnStateRepository.current().state == VpnState.ON && !userStopped.get()) {
                    app.vpnStateRepository.update(app.vpnStateRepository.current().copy(state = VpnState.CONNECTING, error = null))
                    notifications.notify(app.vpnStateRepository.current())
                }
            }

            override fun onAvailable(network: Network) {
                if (app.vpnStateRepository.current().state == VpnState.CONNECTING && !userStopped.get()) reconnectFinite()
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(callback); networkCallback = callback }
    }

    private fun setError(message: String) {
        val current = app.vpnStateRepository.current()
        val error = current.copy(state = VpnState.ERROR, error = message, downBytesPerSecond = 0, upBytesPerSecond = 0)
        app.vpnStateRepository.update(error)
        notifications.notify(error)
    }

    private fun disconnectInternal(byUser: Boolean) {
        if (byUser) userStopped.set(true)
        reconnectJob?.cancel(); metricsJob?.cancel()
        closeTunnelAndCore()
        app.vpnStateRepository.update(VpnSnapshot(VpnState.OFF))
        notifications.cancel()
        stopForegroundCompat(remove = true)
        stopSelf()
    }

    private fun closeTunnelAndCore() {
        runCatching { XrayNative.stop() }
        runCatching { XrayNative.resetDns() }
        runCatching { tun?.close() }
        tun = null
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat(remove: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(if (remove) STOP_FOREGROUND_REMOVE else STOP_FOREGROUND_DETACH)
        } else {
            stopForeground(remove)
        }
    }

    override fun onRevoke() {
        disconnectInternal(true)
        super.onRevoke()
    }

    override fun onDestroy() {
        metricsJob?.cancel(); reconnectJob?.cancel()
        closeTunnelAndCore()
        networkCallback?.let { runCatching { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } }
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_CONNECT = "com.azadi.freedom.vpnclient.CONNECT"
        const val ACTION_DISCONNECT = "com.azadi.freedom.vpnclient.DISCONNECT"
        const val ACTION_RECONNECT = "com.azadi.freedom.vpnclient.RECONNECT"
        const val EXTRA_PROFILE_ID = "profile_id"
        private const val ATTEMPTS_PER_PROFILE = 2
        private const val MAX_TOTAL_ATTEMPTS = 6
        private const val MAX_PROFILE_CANDIDATES = MAX_TOTAL_ATTEMPTS / ATTEMPTS_PER_PROFILE

        fun connect(context: Context, profileId: String? = null) {
            val intent = Intent(context, AzadiVpnService::class.java).setAction(ACTION_CONNECT)
            profileId?.let { intent.putExtra(EXTRA_PROFILE_ID, it) }
            ContextCompat.startForegroundService(context, intent)
        }

        fun disconnect(context: Context) {
            context.startService(Intent(context, AzadiVpnService::class.java).setAction(ACTION_DISCONNECT))
        }

        fun reconnect(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, AzadiVpnService::class.java).setAction(ACTION_RECONNECT))
        }
    }
}
