package com.azadi.freedom.vpnclient.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.azadi.freedom.vpnclient.R
import com.azadi.freedom.vpnclient.data.Profile
import com.azadi.freedom.vpnclient.databinding.ItemProfileBinding
import com.azadi.freedom.vpnclient.testing.ScoreEngine

class ProfileAdapter(
    private val onSelect: (Profile) -> Unit,
    private val onLongPress: (Profile) -> Unit,
) : RecyclerView.Adapter<ProfileAdapter.Holder>() {
    private var items: List<Profile> = emptyList()
    private var selectedId: String? = null

    fun submit(profiles: List<Profile>, selected: String?) {
        items = profiles.sortedWith(compareByDescending<Profile> {
            ScoreEngine.calculate(it.lastLatencyMs, it.lastJitterMs, it.lastSuccessRatio).score
        }.thenBy { it.name.lowercase() })
        selectedId = selected
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        ItemProfileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position])

    inner class Holder(private val b: ItemProfileBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(profile: Profile) {
            b.name.text = profile.name
            b.protocolBadge.text = profile.protocol.name
            b.details.text = "${profile.transport.uppercase()} • ${profile.security.uppercase()} • ${profile.address}:${profile.port}"
            val score = ScoreEngine.calculate(profile.lastLatencyMs, profile.lastJitterMs, profile.lastSuccessRatio)
            b.latency.text = profile.lastLatencyMs?.let { "$it ms\n${score.label}" } ?: profile.lastError ?: "تست نشده"
            b.card.strokeWidth = if (profile.id == selectedId) 3 else 1
            b.card.setStrokeColor(b.root.context.getColor(if (profile.id == selectedId) R.color.azadi_gold else android.R.color.darker_gray))
            b.root.setOnClickListener { onSelect(profile) }
            b.root.setOnLongClickListener { onLongPress(profile); true }
        }
    }
}
