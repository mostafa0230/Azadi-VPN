package com.azadi.freedom.vpnclient.data

enum class ProxyProtocol { VLESS, VMESS }

data class Profile(
    val id: String,
    val name: String,
    val protocol: ProxyProtocol,
    val rawLink: String,
    val address: String,
    val port: Int,
    val transport: String,
    val security: String,
    val createdAt: Long = System.currentTimeMillis(),
    val lastLatencyMs: Long? = null,
    val lastJitterMs: Long? = null,
    val lastSuccessRatio: Double? = null,
    val lastTestAt: Long? = null,
    val lastError: String? = null,
) {
    fun safeSummary(): String = "${protocol.name} • ${security.ifBlank { transport }}"
}
