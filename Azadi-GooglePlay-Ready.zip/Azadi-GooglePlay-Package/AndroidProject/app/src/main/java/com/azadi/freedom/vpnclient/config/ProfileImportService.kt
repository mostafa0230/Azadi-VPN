package com.azadi.freedom.vpnclient.config

import com.azadi.freedom.vpnclient.core.XrayNative
import com.azadi.freedom.vpnclient.data.Profile
import com.azadi.freedom.vpnclient.data.ProfileStore
import org.json.JSONObject

class ProfileImportService(private val store: ProfileStore) {
    data class Result(
        val imported: List<Profile>,
        val duplicates: List<String>,
        val rejected: List<String>,
    )

    fun importText(text: String): Result {
        var normalized = text.trim()
        val rejected = mutableListOf<String>()

        if (normalized.startsWith("{")) {
            val looksLikeVmessShare = runCatching {
                val o = JSONObject(normalized); o.has("add") && o.has("id")
            }.getOrDefault(false)
            if (!looksLikeVmessShare) {
                normalized = try {
                    XrayNative.convertXrayJsonToShareLinks(normalized)
                } catch (t: Throwable) {
                    return Result(emptyList(), emptyList(), listOf(t.message ?: "JSON Xray معتبر نیست"))
                }
            }
        }

        val parsed = ImportEngine.parseMany(normalized, store.getAll().map { it.id }.toSet())
        rejected += parsed.rejected.map { it.reason }
        val nativeValid = mutableListOf<Profile>()
        parsed.imported.forEach { profile ->
            try {
                XrayNative.convertShareLink(profile.rawLink) // validates against current Xray-core builder
                nativeValid += profile
            } catch (t: Throwable) {
                rejected += "${profile.name}: ${t.message ?: "کانفیگ توسط Xray رد شد"}"
            }
        }
        store.add(nativeValid)
        if (store.getSelectedId() == null && nativeValid.isNotEmpty()) store.setSelectedId(nativeValid.first().id)
        return Result(nativeValid, parsed.duplicates, rejected)
    }
}
