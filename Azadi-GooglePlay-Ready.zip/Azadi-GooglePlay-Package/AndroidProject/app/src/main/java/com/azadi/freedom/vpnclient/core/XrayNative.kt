package com.azadi.freedom.vpnclient.core

import android.net.VpnService
import libXray.DialerController
import libXray.LibXray
import org.json.JSONArray
import org.json.JSONObject

class XrayException(message: String) : Exception(message)

data class PingNativeResult(val success: Boolean, val delayMs: Long, val error: String?)

class VpnSocketProtector(private val service: VpnService) : DialerController {
    override fun protectFd(fd: Long): Boolean = service.protect(fd.toInt())
}

object XrayNative {
    private const val API_VERSION = 2

    data class InvokeResponse(val success: Boolean, val data: Any?, val error: String?)

    fun registerProtector(protector: DialerController) {
        LibXray.registerDialerController(protector)
    }

    fun setDns(protector: DialerController, server: String) {
        LibXray.setDNS(protector, server)
    }

    fun resetDns() = LibXray.resetDNS()

    fun convertShareLink(link: String): JSONObject {
        val response = invoke("convertShareLinksToXrayJson", JSONObject().put("text", link))
        if (!response.success) throw XrayException(response.error ?: "Xray نتوانست کانفیگ را اعتبارسنجی کند")
        return when (val data = response.data) {
            is JSONObject -> data
            is String -> JSONObject(data)
            else -> throw XrayException("پاسخ تبدیل کانفیگ از Xray نامعتبر است")
        }
    }

    fun convertXrayJsonToShareLinks(xrayJson: String): String {
        val response = invoke("convertXrayJsonToShareLinks", JSONObject().put("xrayJson", xrayJson))
        if (!response.success) throw XrayException(response.error ?: "Xray JSON قابل تبدیل نیست")
        return (response.data as? JSONObject)?.optString("links")
            ?.takeIf { it.isNotBlank() }
            ?: throw XrayException("JSON هیچ VLESS/VMess قابل Export ندارد")
    }

    fun validateConfig(config: JSONObject) {
        val response = invoke("testXray", JSONObject().put("xrayJson", config.toString()))
        if (!response.success) throw XrayException(response.error ?: "Xray configuration is invalid")
    }

    fun run(config: JSONObject) {
        val response = invoke("runXray", JSONObject().put("xrayJson", config.toString()))
        if (!response.success) throw XrayException(response.error ?: "Xray failed to start")
    }

    fun stop() {
        val response = invoke("stopXray", null)
        if (!response.success) throw XrayException(response.error ?: "Xray failed to stop")
    }

    fun isRunning(): Boolean {
        val response = invoke("getXrayState", null)
        if (!response.success) return false
        return (response.data as? JSONObject)?.optBoolean("running", false) ?: false
    }

    fun version(): String? {
        val response = invoke("xrayVersion", null)
        return if (response.success) (response.data as? JSONObject)?.optString("version") else null
    }

    fun pingBatch(configs: List<JSONObject>, timeoutSeconds: Int = 5): List<PingNativeResult> {
        require(configs.size <= 5) { "libXray pingBatch accepts at most five configs" }
        val configArray = JSONArray()
        configs.forEach { config ->
            configArray.put(JSONObject().put("xrayJson", config.toString()))
        }
        val payload = JSONObject()
            .put("configs", configArray)
            .put("timeout", timeoutSeconds.coerceIn(1, 30))
            .put("url", "https://cp.cloudflare.com/")
        val response = invoke("pingBatch", payload)
        if (!response.success) throw XrayException(response.error ?: "Server test failed")
        val results = (response.data as? JSONObject)?.optJSONArray("results") ?: JSONArray()
        return buildList {
            for (i in 0 until results.length()) {
                val item = results.getJSONObject(i)
                add(PingNativeResult(
                    success = item.optBoolean("success", false),
                    delayMs = item.optLong("delay", 10_000L),
                    error = item.optString("error").takeIf { it.isNotBlank() },
                ))
            }
        }
    }

    private fun invoke(method: String, payload: JSONObject?): InvokeResponse {
        val request = JSONObject().put("apiVersion", API_VERSION).put("method", method)
        if (payload != null) request.put("payload", payload)
        val raw = LibXray.invoke(request.toString())
        val response = JSONObject(raw)
        val success = response.optBoolean("success", false)
        val data = if (response.has("data") && !response.isNull("data")) response.get("data") else null
        val error = response.optString("error").takeIf { it.isNotBlank() }
        return InvokeResponse(success, data, error)
    }
}
