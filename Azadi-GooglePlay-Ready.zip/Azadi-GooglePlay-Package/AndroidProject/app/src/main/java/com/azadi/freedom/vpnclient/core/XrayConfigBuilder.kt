package com.azadi.freedom.vpnclient.core

import org.json.JSONArray
import org.json.JSONObject

object XrayConfigBuilder {
    const val METRICS_PORT = 49227
    private const val FALLBACK_PROXY_TAG = "azadi-proxy"
    private const val TUN_TAG = "azadi-tun"

    fun fromShareLink(rawLink: String, tunFd: Int): JSONObject {
        val config = XrayNative.convertShareLink(rawLink)
        val outbounds = config.optJSONArray("outbounds")
            ?: throw XrayException("کانفیگ Xray هیچ outbound معتبری ندارد")
        if (outbounds.length() == 0) throw XrayException("کانفیگ Xray هیچ outbound معتبری ندارد")

        // Preserve an existing tag because dependent outbounds may reference it.
        // Add a deterministic tag only when the imported primary outbound has none.
        val primary = outbounds.getJSONObject(0)
        val proxyTag = primary.optString("tag").takeIf { it.isNotBlank() } ?: FALLBACK_PROXY_TAG
        if (!primary.has("tag") || primary.optString("tag").isBlank()) primary.put("tag", proxyTag)
        config.put("outbounds", outbounds)

        config.put("inbounds", JSONArray().put(
            JSONObject()
                .put("tag", TUN_TAG)
                .put("protocol", "tun")
                .put("port", 0)
                .put("settings", JSONObject().put("mtu", 1500))
        ))

        val env = config.optJSONObject("env") ?: JSONObject()
        env.put("xray.tun.fd", tunFd.toString())
        config.put("env", env)

        val routing = config.optJSONObject("routing") ?: JSONObject()
        val rules = routing.optJSONArray("rules") ?: JSONArray()
        rules.put(JSONObject()
            .put("type", "field")
            .put("inboundTag", JSONArray().put(TUN_TAG))
            .put("outboundTag", proxyTag))
        routing.put("rules", rules)
        config.put("routing", routing)

        config.put("metrics", JSONObject().put("listen", "127.0.0.1:$METRICS_PORT"))
        val policy = config.optJSONObject("policy") ?: JSONObject()
        val system = policy.optJSONObject("system") ?: JSONObject()
        system.put("statsInboundDownlink", true)
        system.put("statsInboundUplink", true)
        system.put("statsOutboundDownlink", true)
        system.put("statsOutboundUplink", true)
        policy.put("system", system)
        config.put("policy", policy)
        config.put("stats", config.optJSONObject("stats") ?: JSONObject())

        return config
    }

    fun outboundOnly(rawLink: String): JSONObject = XrayNative.convertShareLink(rawLink)
}
