package com.azadi.freedom.vpnclient.ads

import android.app.Activity
import android.content.Context
import com.azadi.freedom.vpnclient.BuildConfig
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import java.util.concurrent.atomic.AtomicBoolean

class AdManager(private val context: Context) {
    private val initialized = AtomicBoolean(false)
    private var interstitial: InterstitialAd? = null
    private var lastInterstitialAt = 0L

    fun initialize() {
        if (initialized.compareAndSet(false, true)) MobileAds.initialize(context) { }
    }

    fun createBanner(): AdView = AdView(context).apply {
        adUnitId = BuildConfig.ADMOB_BANNER_ID
        setAdSize(AdSize.BANNER)
        loadAd(AdRequest.Builder().build())
    }

    fun preloadInterstitial() {
        if (interstitial != null) return
        InterstitialAd.load(
            context,
            BuildConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
            },
        )
    }

    /** Only call after a natural, non-connectivity-critical action such as completed server testing/import. */
    fun showNaturalInterstitial(activity: Activity) {
        val now = System.currentTimeMillis()
        if (now - lastInterstitialAt < MIN_INTERVAL_MS) return
        val ad = interstitial ?: return
        interstitial = null
        lastInterstitialAt = now
        ad.show(activity)
        preloadInterstitial()
    }

    companion object { private const val MIN_INTERVAL_MS = 5 * 60 * 1000L }
}
