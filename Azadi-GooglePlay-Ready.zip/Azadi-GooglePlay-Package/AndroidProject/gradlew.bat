@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Open this project in Android Studio, or install Gradle 8.13 and run gradle %*.
exit /b 1
