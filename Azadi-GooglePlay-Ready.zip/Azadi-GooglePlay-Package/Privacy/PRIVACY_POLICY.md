# Privacy Policy — Azadi / آزادی

**Effective date:** 14 August 2026  
**App:** Azadi (آزادی)  
**Android application ID:** `com.azadi.freedom.vpnclient`  
**Developer/Legal entity:** `[DEVELOPER OR COMPANY NAME]`  
**Contact:** `[PRIVACY CONTACT EMAIL]`  
**Website:** `[PUBLIC WEBSITE URL]`

This policy describes how the Azadi Android application processes information. Replace the contact placeholders and publish the HTML version on a public HTTPS URL before releasing the app.

## 1. What Azadi does

Azadi is a VPN client. It lets users import and manage VLESS and VMess connection profiles and uses Android's `VpnService` together with Xray-core to route device network traffic through the server selected by the user. Azadi does not provide or operate the servers contained in user-imported profiles unless the developer separately states otherwise in a future version.

## 2. VPN traffic and network processing

When the VPN is connected, Android sends network packets to the app's VPN interface. Xray-core processes those packets locally and forwards them through the VLESS or VMess connection selected by the user. The selected remote server necessarily receives network traffic required to provide the proxy/VPN connection. The operator of that server may be able to observe connection metadata and, for traffic that is not end-to-end encrypted by the destination application/protocol, potentially traffic content. Users should only use servers they trust and are authorized to use.

The Google Play-oriented build rejects VLESS profiles that use `security=none` and rejects VMess profiles configured with no cipher, because the VPN transport to its endpoint must be encrypted.

Azadi does not intentionally create a developer-side log of websites or applications visited through the VPN. This version does not include a developer analytics backend or a crash-reporting SDK such as Firebase Crashlytics.

## 3. VPN configuration data

Imported profiles can include server hostname/IP, port, protocol parameters, UUID or similar authentication material, transport settings, SNI, paths, public keys, and other connection parameters. Azadi stores profile data in the app's private storage encrypted with a key held by Android Keystore using AES-GCM.

Profile data remains on the device unless the user explicitly exports it or uses it to connect. Exported configuration files can contain secrets. Users are responsible for protecting exported files and QR codes.

## 4. Server testing and diagnostics

When the user chooses to test servers, Azadi uses Xray/libXray to make real test requests through the imported profiles. The current test target is Cloudflare's connectivity endpoint (`https://cp.cloudflare.com/`). These requests are used to measure success/failure and latency; three real measurements are used to estimate reliability and jitter. The app does not generate random test results.

The tested proxy server and the test destination may receive ordinary network metadata such as source/exit IP addresses and request timing. Test results (for example latency, success ratio, jitter, timestamp, and error text) are stored locally with the profile.

## 5. DNS

While connected, Azadi assigns public DNS addresses to the Android VPN interface so device DNS packets are captured by the VPN route and forwarded through the selected tunnel. Xray's own resolver may use a protected DNS socket to resolve the proxy server itself without routing that socket back into the VPN and creating a loop. DNS providers may process DNS requests according to their own policies.

No VPN application can honestly guarantee that every device, application, OEM modification, captive portal, or network condition will be leak-free in all circumstances. Users should validate DNS behavior on their target devices and networks.

## 6. QR scanner and camera

The optional QR import feature uses the camera only when the user opens the QR scanner. QR image data is processed for decoding on the device by the scanner library. Azadi does not intentionally upload or retain camera frames. The decoded configuration text may contain credentials and is treated like any other imported profile.

## 7. Advertising and Google AdMob

Azadi is intended to be free and supported by advertising. It integrates Google Mobile Ads (AdMob). Google states that the current Mobile Ads SDK automatically collects and shares certain data for advertising, analytics, and fraud prevention, including:

- IP address, which may be used to estimate general location;
- product/app interaction information;
- diagnostic information;
- device/account identifiers, including Android advertising ID where available and permitted.

Google states that this SDK data is encrypted in transit. Ad data handling can change as SDK versions change; the developer must keep this policy and the Google Play Data Safety form synchronized with the actual SDK version and configuration.

Azadi does not display ads in the Quick Settings tile or foreground VPN notification, and interstitial ads are not used to gate Connect or Disconnect actions.

## 8. Consent and privacy choices

Azadi uses Google's User Messaging Platform (UMP) to obtain and refresh advertising consent information where required, including relevant European-region consent flows. Ads are initialized only when the current consent state allows ad requests. A Privacy Options entry is made available in Settings when UMP indicates that such an entry point is required.

Users may also control or delete the Android advertising ID through Android system settings where supported.

## 9. Permissions

Azadi uses only permissions tied to implemented features, including Internet access, network state, foreground VPN service, notifications, optional camera access for QR import, and advertising ID access associated with the configured Google ads SDK. The VPN and Quick Settings services also use Android system binding permissions that are not ordinary runtime permissions granted to the app.

## 10. Data retention

VPN profiles and test results remain locally on the device until the user deletes profiles, clears app data, or uninstalls the app. The app does not maintain an Azadi cloud account in version 1.0.0.

Advertising/consent data handled by Google is retained according to Google's policies and the applicable consent state. Remote VPN/proxy servers and DNS/test service providers may have their own retention practices, which Azadi does not control.

## 11. Sharing

Azadi does not sell user-imported VPN profiles. Data leaves the device only as required by user actions and integrated services, including:

- network traffic sent through the user-selected proxy/VPN endpoint;
- DNS traffic required for name resolution;
- user-initiated server test traffic;
- advertising, consent, analytics/diagnostic and anti-fraud data processed by Google Mobile Ads/UMP as described above;
- configuration data explicitly exported by the user.

## 12. Security

Azadi uses Android Keystore-backed encryption for locally stored proxy credentials and Android's VPN APIs for the tunnel. No security mechanism can guarantee absolute protection. Users should keep Android updated, protect device access, avoid untrusted configuration sources, and treat exported configuration links as secrets.

## 13. Children

Azadi is a network utility and is not designed or marketed specifically for children. The Play Console target-audience declaration and AdMob settings must match the final distribution plan. If the developer later chooses to target children, the ads, consent, data practices, and SDK configuration must be reassessed before release.

## 14. User rights

Depending on location, users may have rights concerning personal data processed by the developer or advertising partners, such as access, correction, deletion, objection, restriction, or withdrawal of consent. Because version 1.0.0 has no Azadi cloud account, locally stored Azadi profile data can be deleted from the app or by clearing app storage/uninstalling. For requests concerning developer-controlled data, contact `[PRIVACY CONTACT EMAIL]`. For Google-controlled advertising data, users may also use Google's privacy and advertising controls.

## 15. International processing

Third-party services such as Google advertising/consent services, user-selected VPN servers, DNS providers, and network test destinations may process data in countries outside the user's residence. Their own terms and privacy policies apply.

## 16. Changes

This policy may be updated when app functionality, SDKs, data practices, or legal requirements change. The effective date at the top will be updated when material changes are published.

## 17. Contact

**Developer/Company:** `[DEVELOPER OR COMPANY NAME]`  
**Privacy email:** `[PRIVACY CONTACT EMAIL]`  
**Postal address (if applicable):** `[POSTAL ADDRESS]`
