# آزادی (Azadi) — Android VPN Client

Version: **1.0.0** (`versionCode=1`)

Final Android application ID used by this project: **`com.azadi.freedom.vpnclient`**.

The originally suggested `com.azadi.vpn` is already associated with a previously distributed Android app, so it was deliberately not reused. A public web search did not show a matching app for `com.azadi.freedom.vpnclient`, but only Google Play Console can definitively confirm that an application ID is available for a new Play app.

## What this project actually implements

- Android `VpnService` full-device tunnel.
- Official XTLS/libXray wrapper around Xray-core.
- Xray Android TUN fd integration using root config `env["xray.tun.fd"]`.
- VLESS import (TLS/Reality required by this Play-oriented build).
- VMess Base64/JSON import (unencrypted `scy=none` rejected).
- Multiple-link paste, file/JSON import, QR scan, export, duplicate detection.
- Native Xray validation before a profile is accepted.
- Encrypted on-device profile storage using Android Keystore + AES-GCM.
- Real `pingBatch` tests, 3 rounds per profile, latency/jitter/reliability scoring.
- Best-server selection and connection.
- Finite reconnect/fallback attempts; no infinite reconnect loop.
- Android Quick Settings `TileService` that starts/stops the real VPN after one-time VPN consent has been granted.
- Foreground VPN notification.
- Real traffic counters read from Xray's local `/debug/vars` metrics endpoint.
- IPv4 and IPv6 routes through the TUN.
- DNS routed through the VPN for device traffic; protected resolver used for Xray's own upstream resolution.
- System Kill Switch guidance: Android's Always-on VPN + “Block connections without VPN”. The app does not pretend it can silently enable this protected system setting.
- Google Mobile Ads SDK + UMP consent. Debug builds use Google's test IDs only.

## No fake binaries

`Release/` intentionally contains no APK/AAB in this copy because the current generation environment did not have Android SDK/NDK/Gradle and shell network downloads are restricted. `Release/BUILD_NOT_PRODUCED_IN_THIS_ENVIRONMENT.txt` explains this explicitly.

A real build is produced by:

```bash
cd AndroidProject
./scripts/build-all.sh
```

or by `.github/workflows/android-build.yml` on GitHub Actions.

Expected real outputs:

```text
Release/Azadi-debug.apk
Release/Azadi-release.aab
Release/SHA256SUMS.txt
```

## Release signing

No private keystore is included. Set these environment variables before the release build:

```text
AZADI_KEYSTORE_PATH
AZADI_KEYSTORE_PASSWORD
AZADI_KEY_ALIAS
AZADI_KEY_PASSWORD
```

For CI, use repository secrets described in `Documentation/BUILD.md`.

## AdMob production IDs

Debug always uses Google's official test ad identifiers. Before publishing, set:

```text
AZADI_ADMOB_APP_ID
AZADI_ADMOB_BANNER_ID
AZADI_ADMOB_INTERSTITIAL_ID
```

Never publish a build that still reports test IDs.

## Permissions

| Permission | Reason | Required? |
|---|---|---|
| `INTERNET` | Xray tunnel, server testing, ads | Yes |
| `ACCESS_NETWORK_STATE` | Detect network changes for reconnect behavior | Yes |
| `FOREGROUND_SERVICE` | Keep an active VPN service alive | Yes |
| `FOREGROUND_SERVICE_SPECIAL_USE` | Android 14+ foreground-service type used by the VPN service | Yes for current implementation |
| `POST_NOTIFICATIONS` | Show foreground VPN status notification on Android 13+ | Requested at runtime; VPN can still be managed if user denies notification permission, subject to Android behavior |
| `CAMERA` | QR code scanning only | Optional feature; requested by scanner only when used |
| `AD_ID` | Google Mobile Ads measurement/advertising where available | Used by the configured ads SDK; review against final ads mode/Play declarations |
| `BIND_VPN_SERVICE` | Applied to the service component so only Android can bind as a VPN service | System signature permission, not runtime user permission |
| `BIND_QUICK_SETTINGS_TILE` | Applied to the tile service component | System binding permission, not runtime user permission |

## Important limits

1. The one-time Android VPN consent UI must be granted from an Activity. Before that consent exists, a Quick Settings tile cannot silently grant itself VPN permission; it opens the app for the system consent step. After consent, the tile directly controls the actual VPN service.
2. The app cannot silently enable Android's system-level “Block connections without VPN”. The Settings button opens the real Android VPN settings where the user can enable Always-on VPN and the block-without-VPN option.
3. Server “throughput” is not fabricated. Version 1.0 reports latency, success/failure, timeout, jitter/stability, and live tunnel byte rate. A standalone bulk throughput benchmark is intentionally omitted until a defined test endpoint/payload is chosen.
4. Country flags are not guessed from hostnames/IPs. Profiles show their actual imported names; a future GeoIP feature should use an explicit, documented database.
5. VLESS `security=none` is rejected in this Google-Play-oriented build because Play's VpnService policy requires encryption from the device to the VPN tunnel endpoint.
6. This app is a client for user-supplied servers. It does not provide VPN servers itself.

## Source licenses

- XTLS/libXray: MIT.
- Xray-core: MPL-2.0.
- Android/AndroidX/Google SDKs and ZXing retain their respective licenses.

See `Documentation/THIRD_PARTY_NOTICES.md`.
