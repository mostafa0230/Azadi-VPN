# BUILD — Azadi 1.0.0

## Requirements

- Linux/macOS or GitHub Actions (Windows can build the Android app, but the included native script is documented primarily for Unix-like shells).
- JDK 21 (AGP runs with Java 17+; CI uses 21 to match the native build environment).
- Android SDK Platform 36 and Build Tools 36.0.0.
- Android NDK r29 for the current official libXray Android build workflow.
- Git.
- Python 3.
- Go (current stable; libXray's `go.mod` governs module requirements).
- curl + unzip if using the bootstrap `./gradlew` and no system Gradle is installed.

## Build native core

```bash
cd AndroidProject
./scripts/build-libxray.sh
```

This clones the pinned `XTLS/libXray` tag `v26.7.28`, calls its official Android build command, and copies the resulting real `libXray.aar` to `app/libs/`.

## Required verification commands

```bash
./gradlew clean
./gradlew test
./gradlew assembleDebug
./gradlew bundleRelease
```

`./scripts/build-all.sh` runs the native build and all four commands, then copies outputs into the package `Release/` directory.

## Debug APK

```text
AndroidProject/app/build/outputs/apk/debug/app-debug.apk
```

Copied as:

```text
Release/Azadi-debug.apk
```

## Release AAB

```text
AndroidProject/app/build/outputs/bundle/release/app-release.aab
```

Copied as:

```text
Release/Azadi-release.aab
```

## Signing

Create your own upload key. Never commit it.

Example:

```bash
keytool -genkeypair -v \
  -keystore azadi-upload.jks \
  -alias azadi-upload \
  -keyalg RSA -keysize 4096 -validity 10000
```

Then export only local/CI environment variables:

```bash
export AZADI_KEYSTORE_PATH=/absolute/path/azadi-upload.jks
export AZADI_KEYSTORE_PASSWORD='...'
export AZADI_KEY_ALIAS='azadi-upload'
export AZADI_KEY_PASSWORD='...'
```

The Gradle file configures release signing only when all four variables are present.

## GitHub Actions

Push the package root to a private repository and run `Build Azadi Android`.

Optional signing secrets:

```text
AZADI_KEYSTORE_BASE64
AZADI_KEYSTORE_PASSWORD
AZADI_KEY_ALIAS
AZADI_KEY_PASSWORD
```

Create the first secret locally without exposing the file:

```bash
base64 -w 0 azadi-upload.jks
```

Also add production AdMob secrets before a Play build:

```text
AZADI_ADMOB_APP_ID
AZADI_ADMOB_BANNER_ID
AZADI_ADMOB_INTERSTITIAL_ID
```

## Build status in this delivery environment

Android SDK/NDK and Gradle were not installed in the active runtime, and shell downloads of binary distributions were restricted. Therefore the source was prepared but no fake APK/AAB was inserted.
## 16 KB native page-size verification

Azadi targets API 36 and contains native code through libXray. After creating the debug APK, verify ZIP/page alignment with Android Build Tools 36:

```bash
$ANDROID_HOME/build-tools/36.0.0/zipalign -c -P 16 -v 4 app/build/outputs/apk/debug/app-debug.apk
```

The included GitHub Actions workflow runs this check automatically before copying the APK/AAB to `Release/`.

