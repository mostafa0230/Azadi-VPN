# PUBLISH — Google Play

1. Build a real signed release AAB with your private upload key. Do not place the private key in the repository or ZIP.
2. Create the Play app using application ID `com.azadi.freedom.vpnclient`. If Play Console reports a collision, choose a new permanent ID before the first production upload; application IDs cannot be safely changed after publication.
3. Target API is 36.
4. Complete App content > VpnService declaration and explicitly state that the app's core purpose is a user-configured VPN client using Android VpnService and Xray-core.
5. Declare the `specialUse` foreground-service use case in Play Console consistently with the manifest: an active user-initiated VPN tunnel that must continue in the foreground.
6. Host `Privacy/privacy-policy.html` on a public HTTPS URL. Play policy requires an active public, non-geofenced privacy-policy URL; do not submit a local file or PDF.
7. Complete Data Safety using `Play-Console/data-safety-draft.txt` and re-check the current Google Mobile Ads SDK disclosure before submitting.
8. Complete Content Rating using `Play-Console/content-rating-notes.txt`.
9. Configure the target audience as a general utility audience; do not target children unless the entire ads/data implementation is redesigned for Families requirements.
10. Replace all AdMob test configuration with your production app/ad unit IDs, while retaining test IDs for debug builds.
11. Upload real app screenshots captured from an installed build. Do not use the screenshot placeholders/status notes as store screenshots.
12. Upload a real 512×512 app icon and 1024×500 feature graphic after final brand asset generation.
13. Verify Store Listing explicitly mentions Android VpnService and user-supplied VLESS/VMess profiles; avoid anonymity, guaranteed speed, “unblock everything,” or other claims the app cannot guarantee.
14. Upload the signed `.aab`, use Internal testing first, install from Play, and retest VLESS TLS/Reality, VMess, Tile, reconnect, consent, ads, IPv4/IPv6 and system kill-switch instructions.
15. Review the release checklist before production rollout.

VPN publishing may require an organization developer account under current Google Play policy/account requirements. Verify the requirement for your developer account in Play Console before submission.
## Native compatibility gate

Before Play upload, confirm the APK passes Android's 16 KB alignment check. The included CI workflow performs this automatically. Treat a failed alignment check as a release blocker.

