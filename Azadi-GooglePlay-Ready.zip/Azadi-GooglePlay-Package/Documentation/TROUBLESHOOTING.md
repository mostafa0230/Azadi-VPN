# TROUBLESHOOTING

## `libXray.aar` not found

Run:

```bash
cd AndroidProject
./scripts/build-libxray.sh
```

Verify `app/libs/libXray.aar` exists before Gradle compilation.

## VPN consent keeps opening

Only Android can grant VpnService consent. Complete the system dialog once. A reinstall, app-data clear, device policy, or another VPN becoming prepared can require consent again.

## Tile opens the app instead of connecting

This is expected before initial VpnService consent or when no profile exists. After consent and profile selection, the tile sends real connect/disconnect commands to `AzadiVpnService`.

## Xray starts but there is no traffic

Check:

1. Imported profile passes Xray validation.
2. Upstream server is reachable.
3. VLESS uses TLS or Reality in this Play build.
4. Device has no conflicting Always-on VPN.
5. Xray runtime state reports running.
6. `xray.tun.fd` is present in the generated root `env` object.
7. Socket protection succeeds so Xray's own outbound socket does not loop back into the VPN.

## Server tests fail while VPN is on

By design, testing is disabled while the managed Xray tunnel is active. libXray documents process-wide state that can be affected by temporary test instances. Disconnect first, then test.

## Notification speed stays at zero

The app reads real Xray inbound counters from `127.0.0.1:49227/debug/vars`. If the metrics endpoint is unavailable or the tunnel has no traffic, zero is shown. It never generates random speed values.

## Kill Switch

Use Android Settings > Network & Internet > VPN > Azadi > Always-on VPN and enable “Block connections without VPN” where supported. The app deliberately does not fake or silently change this protected system setting.
