# Third-party notices

## XTLS/libXray

Project: https://github.com/XTLS/libXray
License: MIT
Pinned integration tag for this project: v26.7.28

## Xray-core

Project: https://github.com/XTLS/Xray-core
License: Mozilla Public License 2.0 (MPL-2.0)

The application dynamically builds/links the official mobile wrapper. Preserve required notices and satisfy MPL-2.0 obligations for covered modifications if Xray-core itself is modified.

## ZXing Android Embedded

Used for optional QR scanning. Preserve its upstream license notices.

## Google Mobile Ads / UMP

Distributed under Google's applicable SDK terms, not an open-source license. Production use requires compliance with AdMob, consent, and Google Play policies.
