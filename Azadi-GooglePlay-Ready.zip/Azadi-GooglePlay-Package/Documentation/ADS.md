# ADS — AdMob and Consent

Azadi is free and has no Premium, subscription, or in-app purchase flow.

## SDKs

- Google Mobile Ads SDK: `25.4.0`
- Google User Messaging Platform (UMP): `4.0.0`

## Placement

- Banner: bottom of the main screen after consent state allows ad requests.
- Interstitial: only after a completed import or completed “Test All” action, never on Connect, Disconnect, Quick Settings, or the foreground notification.
- Minimum app-side interval between interstitial displays: 5 minutes.

## Development

Debug builds use only Google's documented test identifiers.

## Production configuration

Provide via Gradle properties/environment in your release pipeline:

```text
AZADI_ADMOB_APP_ID
AZADI_ADMOB_BANNER_ID
AZADI_ADMOB_INTERSTITIAL_ID
```

Do not hard-code production credentials in source control.

## Consent

UMP consent information is refreshed on each app launch. A form is shown when required. Ads are initialized only if the current consent state allows ad requests. Settings exposes the UMP Privacy Options form when Google indicates that an entry point is required.

## Data Safety implication

The Google Mobile Ads SDK currently documents automatic collection/sharing of IP address, product interactions, diagnostics, and device/account identifiers for advertising, analytics, and fraud prevention. Re-check Google's SDK disclosure page immediately before every Play release because SDK behavior and Play form wording can change.
