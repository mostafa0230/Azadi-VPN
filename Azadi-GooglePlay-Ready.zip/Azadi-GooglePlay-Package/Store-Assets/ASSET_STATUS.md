# Store asset status

No fake store screenshots are included in this source package.

The original requirement says screenshots must show the real running UI and must not be fabricated. Because this environment could not build/install the Android APK, real screenshots cannot truthfully be captured here yet.

Pending after the first real APK build:
- `app-icon-512.png` — final generated lion brand artwork, 512×512.
- `feature-graphic-1024x500.png` — final lion/technology graphic, 1024×500.
- `screenshots/screenshot-01.png` — connected home screen from real installed build.
- `screenshots/screenshot-02.png` — real VLESS/VMess list.
- `screenshots/screenshot-03.png` — real server test/ranking results.
- `screenshots/screenshot-04.png` — real import screen/dialog.
- `screenshots/screenshot-05.png` — real Quick Settings tile + connection state.

Do not upload synthetic screenshots to Play. Capture them from an emulator/device after `Azadi-debug.apk` is built and validated.
